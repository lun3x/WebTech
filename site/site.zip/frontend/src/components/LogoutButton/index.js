import React, { Component } from 'react';
import { Paper } from 'material-ui';
import fetch from 'cross-fetch';
import PropTypes from 'prop-types';
import ApiErrorSnackbar from '../ApiErrorSnackbar';

class LogoutButton extends Component {
    
    static propTypes = {
        //handleAuthChange: PropTypes.func.isRequired,
    }

    render() {
        const style = {

        };

        return (
            <div />
        );
    }
}


export default LogoutButton;
